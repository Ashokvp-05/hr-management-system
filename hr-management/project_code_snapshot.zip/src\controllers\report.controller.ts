import { Request, Response } from 'express';
import * as timeEntryService from '../services/timeEntry.service';
import { AuthRequest } from '../middleware/auth.middleware';

export const getAttendanceReport = async (req: Request, res: Response) => {
    try {
        const { start, end } = req.query;
        if (!start || !end) {
            return res.status(400).json({ error: 'Start and end dates are required' });
        }

        const report = await timeEntryService.getReport(new Date(start as string), new Date(end as string));
        res.json(report);
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
};
