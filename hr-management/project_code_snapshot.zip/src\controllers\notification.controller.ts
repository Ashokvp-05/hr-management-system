import { Request, Response } from 'express';
import * as notificationService from '../services/notification.service';
import { AuthRequest } from '../middleware/auth.middleware';

export const getNotifications = async (req: Request, res: Response) => {
    try {
        const userId = (req as AuthRequest).user?.id;
        if (!userId) return res.status(401).json({ error: 'Unauthorized' });

        const notifications = await notificationService.getUserNotifications(userId);
        res.json(notifications);
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
};

export const markRead = async (req: Request, res: Response) => {
    try {
        const userId = (req as AuthRequest).user?.id;
        if (!userId) return res.status(401).json({ error: 'Unauthorized' });

        const { id } = req.params;
        await notificationService.markAsRead(id, userId);
        res.json({ message: 'Marked as read' });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
};

export const markAllRead = async (req: Request, res: Response) => {
    try {
        const userId = (req as AuthRequest).user?.id;
        if (!userId) return res.status(401).json({ error: 'Unauthorized' });

        await notificationService.markAllAsRead(userId);
        res.json({ message: 'All marked as read' });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
};
