import { auth } from "@/auth"
import { redirect } from "next/navigation"
import Link from "next/link"
import {
    Clock,
    Calendar,
    ArrowUpRight,
    MapPin,
    Zap,
    Briefcase,
    MoreHorizontal
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"

import ClockWidget from "@/components/dashboard/ClockWidget"
import TimeSummary from "@/components/dashboard/TimeSummary"
import TeamAvailabilityWidget from "@/components/dashboard/TeamAvailabilityWidget"
import AttendanceChart from "@/components/dashboard/AttendanceChart"

export default async function DashboardPage() {
    const session = await auth()
    if (!session) redirect("/login")

    const token = (session.user as any)?.accessToken || ""
    const userName = session.user?.name || "Employee"

    // Modern Date Format
    const today = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })

    return (
        <div className="flex-1 max-w-6xl mx-auto w-full space-y-8 pb-10">
            {/* HERDER: Minimal & Clean */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 py-4">
                <div>
                    <p className="text-sm font-medium text-muted-foreground uppercase tracking-widest">{today}</p>
                    <h1 className="text-3xl font-light tracking-tight text-foreground">
                        Hello, <span className="font-semibold">{userName.split(' ')[0]}</span>
                    </h1>
                </div>
                <div className="flex items-center gap-3">
                    <Button variant="outline" className="rounded-full shadow-none border-border/60 hover:bg-muted" asChild>
                        <Link href="/profile">My Profile</Link>
                    </Button>
                    <Button className="rounded-full shadow-lg bg-foreground text-background hover:bg-foreground/90 gap-2" asChild>
                        <Link href="/leave"><Zap className="w-4 h-4 fill-current" /> Request Leave</Link>
                    </Button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">

                {/* LEFT COLUMN: Main Operation (8 cols) */}
                <div className="lg:col-span-8 space-y-8">

                    {/* SECTION 1: Clock In Hero */}
                    <div className="relative group">
                        <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-500 to-purple-600 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
                        <div className="relative bg-background rounded-xl ring-1 ring-border/50">
                            <ClockWidget token={token} />
                        </div>
                    </div>

                    {/* SECTION 2: Analytics & History */}
                    <div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                            {/* Left: Weekly Chart */}
                            <AttendanceChart />

                            {/* Right: Quick Stats Grid */}
                            <div className="grid grid-cols-2 gap-4">
                                <Card className="shadow-sm border-l-4 border-l-emerald-500">
                                    <CardContent className="p-4 flex flex-col justify-center">
                                        <p className="text-xs text-muted-foreground uppercase font-bold">Today</p>
                                        <div className="text-2xl font-bold mt-1">4h 12m</div>
                                        <p className="text-[10px] text-muted-foreground">On Track</p>
                                    </CardContent>
                                </Card>
                                <Card className="shadow-sm border-l-4 border-l-blue-500">
                                    <CardContent className="p-4 flex flex-col justify-center">
                                        <p className="text-xs text-muted-foreground uppercase font-bold">This Week</p>
                                        <div className="text-2xl font-bold mt-1">32h 45m</div>
                                        <p className="text-[10px] text-emerald-600 font-medium">+2.5h Overtime</p>
                                    </CardContent>
                                </Card>
                                <Card className="col-span-2 shadow-sm border-dashed">
                                    <CardContent className="p-4 flex items-center justify-between">
                                        <div>
                                            <p className="text-xs text-muted-foreground uppercase font-bold">Leave Balance</p>
                                            <div className="text-xl font-bold mt-1">12 Days</div>
                                        </div>
                                        <Button variant="ghost" size="sm" asChild>
                                            <Link href="/leave" className="text-xs">Apply Now &rarr;</Link>
                                        </Button>
                                    </CardContent>
                                </Card>
                            </div>
                        </div>
                    </div>

                </div>

                {/* RIGHT COLUMN: Context & Social (4 cols) */}
                <div className="lg:col-span-4 space-y-6">

                    {/* Team Widget - Redesigned container */}
                    <div className="bg-muted/30 rounded-xl p-1 border border-border/50">
                        <TeamAvailabilityWidget />
                    </div>

                    {/* Quick Links List */}
                    <Card className="shadow-sm border-none bg-indigo-600 text-white">
                        <CardContent className="p-6">
                            <h3 className="font-semibold text-lg flex items-center gap-2">
                                <Zap className="w-5 h-5 fill-white" /> Pro Tips
                            </h3>
                            <p className="text-indigo-100 text-sm mt-2 mb-4">
                                Clock in before 9:15 AM to maintain your perfect attendance streak!
                            </p>
                            <Button size="sm" variant="secondary" className="w-full text-indigo-700 font-semibold bg-white hover:bg-indigo-50 border-none">
                                View Attendance Policy
                            </Button>
                        </CardContent>
                    </Card>

                    <div className="rounded-xl border bg-card text-card-foreground shadow-sm p-4">
                        <div className="flex items-center justify-between mb-4">
                            <h4 className="font-medium text-sm">Design Team</h4>
                            <MoreHorizontal className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <div className="space-y-4">
                            <div className="flex items-center gap-3">
                                <div className="h-8 w-8 rounded-full bg-pink-500/10 flex items-center justify-center text-pink-600 font-bold text-xs">JD</div>
                                <div className="flex-1">
                                    <p className="text-sm font-medium">Project "Titan" Sync</p>
                                    <p className="text-xs text-muted-foreground">10:00 AM &bull; Room 302</p>
                                </div>
                            </div>
                            <Separator />
                            <div className="flex items-center gap-3">
                                <div className="h-8 w-8 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-600 font-bold text-xs">HR</div>
                                <div className="flex-1">
                                    <p className="text-sm font-medium">Performance Review</p>
                                    <p className="text-xs text-muted-foreground">Tomorrow, 2:00 PM</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    )
}
