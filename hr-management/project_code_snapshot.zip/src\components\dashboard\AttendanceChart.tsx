"use client"

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"

const data = [
    { day: "Mon", hours: 8.5 },
    { day: "Tue", hours: 9.0 },
    { day: "Wed", hours: 7.5 },
    { day: "Thu", hours: 8.0 },
    { day: "Fri", hours: 6.5 }, // Half day?
    { day: "Sat", hours: 0 },
    { day: "Sun", hours: 0 },
]

export default function AttendanceChart() {
    return (
        <Card className="shadow-sm">
            <CardHeader className="pb-2">
                <CardTitle className="text-base font-semibold">Weekly Performance</CardTitle>
                <CardDescription>You averaged 7.9 hours this week.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="h-[200px] w-full mt-2">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={data}>
                            <XAxis
                                dataKey="day"
                                fontSize={10}
                                tickLine={false}
                                axisLine={false}
                                stroke="#888888"
                            />
                            <YAxis
                                fontSize={10}
                                tickLine={false}
                                axisLine={false}
                                stroke="#888888"
                                tickFormatter={(val) => `${val}h`}
                            />
                            <Tooltip
                                cursor={{ fill: 'transparent' }}
                                contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '12px' }}
                            />
                            <Bar
                                dataKey="hours"
                                fill="currentColor"
                                radius={[4, 4, 0, 0]}
                                className="fill-indigo-500"
                                barSize={30}
                            />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </CardContent>
        </Card>
    )
}
