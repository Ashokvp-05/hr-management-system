import prisma from '../config/db';
import { NotificationType } from '@prisma/client';

export const createNotification = async (userId: string, title: string, message: string, type: NotificationType, actionData?: any) => {
    return prisma.notification.create({
        data: {
            userId,
            title,
            message,
            type,
            actionData: actionData || {}
        }
    });
};

export const getUserNotifications = async (userId: string, limit = 20) => {
    return prisma.notification.findMany({
        where: { userId },
        orderBy: { createdAt: 'desc' },
        take: limit
    });
};

export const markAsRead = async (notificationId: string, userId: string) => {
    // Ensure the notification belongs to the user
    const notification = await prisma.notification.findFirst({
        where: { id: notificationId, userId }
    });

    if (!notification) {
        throw new Error('Notification not found or unauthorized');
    }

    return prisma.notification.update({
        where: { id: notificationId },
        data: { isRead: true }
    });
};

export const markAllAsRead = async (userId: string) => {
    return prisma.notification.updateMany({
        where: { userId, isRead: false },
        data: { isRead: true }
    });
};
