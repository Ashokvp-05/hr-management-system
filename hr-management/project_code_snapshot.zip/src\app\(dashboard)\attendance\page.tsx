import { auth } from "@/auth"
import { redirect } from "next/navigation"
import AttendanceHistoryTable from "@/components/dashboard/AttendanceHistoryTable"
import { CalendarCheck } from "lucide-react"

export default async function AttendancePage() {
    const session = await auth()
    if (!session) redirect("/login")

    const token = (session.user as any)?.accessToken || ""

    return (
        <div className="flex-1 space-y-6 container mx-auto py-6 max-w-5xl">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-3xl font-bold tracking-tight">Attendance History</h2>
                    <p className="text-muted-foreground">Digital log of your work hours and shifts.</p>
                </div>
                <div className="p-3 bg-indigo-50/50 rounded-full">
                    <CalendarCheck className="w-6 h-6 text-indigo-500" />
                </div>
            </div>

            <AttendanceHistoryTable token={token} />
        </div>
    )
}
