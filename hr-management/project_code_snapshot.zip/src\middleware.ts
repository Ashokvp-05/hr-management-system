import { auth } from "@/auth"

export default auth((req) => {
    // optionally handle requests based on req.auth
})
